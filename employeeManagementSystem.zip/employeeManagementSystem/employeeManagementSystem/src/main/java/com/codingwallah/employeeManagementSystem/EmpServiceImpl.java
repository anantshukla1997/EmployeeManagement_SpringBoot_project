package com.codingwallah.employeeManagementSystem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EmpServiceImpl implements EmpService {

    @Autowired
  private   EmployeeRepository employeeRepository;
    //List<Employee>employees=new ArrayList<>();
    @Override
    public String createEmployee(Employee employee){
        //Employee employees=new Employee();
        employeeRepository.save(employee);
        return "saved successfully";
    }
    @Override
    public List<Employee> readEmployee(){
       // or  return  employeeRepository.findAll();
        List<Employee> employeeList = employeeRepository.findAll();
        return employeeList ;
    }
    @Override
    public boolean deleteEmployee(Long id){
      //  return employees.removeIf(employee -> employee.getId().equals(id));
        if (employeeRepository.existsById(id)) {
            employeeRepository.deleteById(id);
            return true;
        }
        return false;
    }
@Override
    public String updateEmployee(Long id,Employee employee){
        Optional<Employee> optionalEmployee = employeeRepository.findById(id);
        if (optionalEmployee.isPresent()) {
            Employee existingEmployee = optionalEmployee.get();
            existingEmployee.setId(employee.getId());
            existingEmployee.setName(employee.getName());
            existingEmployee.setPhone(employee.getPhone());
            existingEmployee.setEmail(employee.getEmail());
            employeeRepository.save(existingEmployee);
            return "updated successfully";
        } else {
            return "employee not found";
        }

}
}
