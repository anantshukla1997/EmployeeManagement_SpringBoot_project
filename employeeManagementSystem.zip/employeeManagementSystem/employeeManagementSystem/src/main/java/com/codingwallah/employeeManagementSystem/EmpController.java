package com.codingwallah.employeeManagementSystem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class EmpController {

    @Autowired
    EmpService empService;

    @GetMapping("employees")
    public List<Employee> getAllEmployees(){
        return empService.readEmployee();
    }

    @PostMapping("employees")
    public String createEmployee(@RequestBody Employee employee){

        empService.createEmployee(employee);
        return "Saved Successfully";
    }
    @DeleteMapping("employees/{id}")
    public String deleteEmployee(@PathVariable Long id){

        if(empService.deleteEmployee(id))
            return " deleted";

        return "not found";
    }
    @PutMapping("employees/{id}")
    public String updateEmployee(@PathVariable Long id, @RequestBody Employee employee){
        return empService.updateEmployee(id, employee);
    }

}
